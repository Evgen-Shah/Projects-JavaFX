module Online {
	
	
	opens application to javafx.graphics, javafx.fxml;
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.controls;
	requires java.sql;
	requires ojdbc8;
}
